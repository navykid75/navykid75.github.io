// ****************************************************************
// Factorials.java
//
// Reads integers from the user and prints the factorial of each.
// 
// ****************************************************************
import java.util.Scanner;
public class Factorials
{
 public static void main(String[] args) 
 {
Scanner scanner = new Scanner(System.in);
char keepGoing = 'y';
while (keepGoing == 'y' || keepGoing == 'Y')
 {
System.out.print("Enter an integer: ");
try{
	int val = scanner.nextInt();
System.out.println("Factorial(" + val + ") = " 
 + MathUtils.factorial(val));}
catch(IllegalArgumentException e){;}
System.out.print("Another factorial? (y/n) ");
keepGoing = scanner.next().charAt(0);
 }
 }
}
