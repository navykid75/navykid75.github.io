import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.*;
public class BufferedConsole{
     public static void main(String[] args) throws IOException{
	BufferedReader in = new BufferedReader(new InputStreamReader (System.in));
	BufferedWriter ou = new BufferedWriter(new OutputStreamWriter(System.out));
	System.out.println("Type or Quit");
	String s = "";
	try{
	 s = in.readLine();
	}
	catch(IOException e){
	System.out.println("error");
	}
	while(!s.equalsIgnoreCase("Quit")){
		StringTokenizer tokenizer = new StringTokenizer(s);
		ou.write(String.valueOf(tokenizer.countTokens()));
		while(tokenizer.hasMoreTokens()){
			ou.write(tokenizer.nextToken());
			ou.newLine();
			s = in.readLine();
		}
		// ou.write(s);
		// ou.newLine();
		// s = in.readLine();
	}
	ou.close();
	in.close();

 }
}